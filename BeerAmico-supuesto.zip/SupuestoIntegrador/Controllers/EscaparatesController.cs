﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.CodeAnalysis.Operations;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using SupuestoIntegrador.Data;
using SupuestoIntegrador.Models;

namespace SupuestoIntegrador.Controllers
{
    public class EscaparatesController : Controller
    {
        private readonly MvcSupuestoIntegrador _context;

        public EscaparatesController(MvcSupuestoIntegrador context)
        {
            _context = context;
        }

        // GET: Escaparates



        //public async Task<IActionResult> Index()
        //{
        //    var mvcSupuestoIntegrador = _context.Productos.Where(p => p.Escaparate == true).Include(p => p.Categoria);
        //    return View(await mvcSupuestoIntegrador.ToListAsync());
        //}


        public async Task<IActionResult> Index(int? id, int? mid, string strCadenaBusqueda)
        {
            var mvcSupuestoIntegrador = _context.Productos.Where(p => p.Escaparate == true);
            ViewData["Categorias"] = _context.Categorias.ToList();
            // [ESTO ME SERVIRÁ PARA UTILIZAR LA BARRA DE BÚSQUEDA CUANDO FUNCIONE] ViewData["BusquedaActual"] = strCadenaBusqueda;


            /// [ESTO TAMBIÉN ME SERVIRÁ DESPUÉS PARA PONER LA BARRA DE BÚSQUED]var nombre = _context.Productos.AsQueryable();

            //if (!String.IsNullOrEmpty(strCadenaBusqueda))
            //{
            //    nombre = nombre.Where(s => s.Texto.Contains(strCadenaBusqueda));
            //}

            //Esta código de aquí hasta abajo es el que se encarga de mostarme las categorías [CATEGORIAS]
            if (id != null)
            {
                var categoria = await _context.Categorias.FirstOrDefaultAsync(m => m.Id == id);
                ViewBag.categoria = categoria.Id;

                if (categoria != null)
                {
                    mvcSupuestoIntegrador = mvcSupuestoIntegrador.Where(p => p.CategoriaId == id);

                    var cat = await _context.Categorias.FirstOrDefaultAsync(m => m.Id == mid);

                    if (cat != null)
                    {
                        ViewBag.cat = cat.Id;
                        mvcSupuestoIntegrador = mvcSupuestoIntegrador.Where(p => p.CategoriaId == mid);
                    }
                }
            }

            return View(await mvcSupuestoIntegrador.ToListAsync());
            //FINAL DE CATEGORÍA



        }

        // GET: Escaparates/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Productos == null)
            {
                return NotFound();
            }

            var producto = await _context.Productos
                .Include(p => p.Categoria)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (producto == null)
            {
                return NotFound();
            }

            return View(producto);
        }

        // GET: Escaparates/Create
        public IActionResult Create()
        {
            ViewData["CategoriaId"] = new SelectList(_context.Categorias, "Id", "Descripcion");
            return View();
        }

        // POST: Escaparates/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Descripcion,Texto,Precio,PrecioCadena,Stock,Escaparate,Imagen,CategoriaId")] Producto producto)
        {
            if (ModelState.IsValid)
            {
                _context.Add(producto);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["CategoriaId"] = new SelectList(_context.Categorias, "Id", "Descripcion", producto.CategoriaId);
            return View(producto);
        }

        // GET: Escaparates/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Productos == null)
            {
                return NotFound();
            }

            var producto = await _context.Productos.FindAsync(id);
            if (producto == null)
            {
                return NotFound();
            }
            ViewData["CategoriaId"] = new SelectList(_context.Categorias, "Id", "Descripcion", producto.CategoriaId);
            return View(producto);
        }

        // POST: Escaparates/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Descripcion,Texto,Precio,PrecioCadena,Stock,Escaparate,Imagen,CategoriaId")] Producto producto)
        {
            if (id != producto.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(producto);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ProductoExists(producto.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["CategoriaId"] = new SelectList(_context.Categorias, "Id", "Descripcion", producto.CategoriaId);
            return View(producto);
        }

        // GET: Escaparates/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Productos == null)
            {
                return NotFound();
            }

            var producto = await _context.Productos
                .Include(p => p.Categoria)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (producto == null)
            {
                return NotFound();
            }

            return View(producto);
        }

        // POST: Escaparates/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Productos == null)
            {
                return Problem("Entity set 'MvcSupuestoIntegrador.Productos'  is null.");
            }
            var producto = await _context.Productos.FindAsync(id);
            if (producto != null)
            {
                _context.Productos.Remove(producto);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ProductoExists(int id)
        {
            return (_context.Productos?.Any(e => e.Id == id)).GetValueOrDefault();
        }


        // GET /Escaparate/AgregarCarrito
        [Authorize(Roles = "Usuario")]
        public async Task<IActionResult> AgregarCarrito(int? id)
        {

            Cliente? cliente = await _context.Clientes.FirstOrDefaultAsync(c => c.Email == User.Identity.Name);

            if (cliente == null)
            {
                return RedirectToAction("Create", "MisDatos", new { role = "Cliente" });
            }

            if (id == null)
            {
                return NotFound();
            }

            var producto = await _context.Productos
                .Include(p => p.Categoria)
                .FirstOrDefaultAsync(m => m.Id == id);

            if (producto == null)
            {
                return NotFound();
            }



            return View(producto);
        }

        // POST /Escaparate/AgregarCarrito
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AgregarCarrito(int id)
        {
            
            // Cargar datos de producto a añadir al carrito
            var producto = await _context.Productos
            .FirstOrDefaultAsync(m => m.Id == id);
            if (producto == null)
            {
                return NotFound();
            }


            // Crear nuevo pedido, si el carrito está vacío y, por tanto, no existe pedido actual
            // La variable de sesión NumPedido almacena el número de pedido del carrito
            //if (string.IsNullOrEmpty(HttpContext.Session.GetString("NumPedido")) )
            if (HttpContext.Session.GetString("NumPedido") == null)
            {
                
                // Crear objeto pedido a agregar
                Pedido pedido = new Pedido();
                pedido.Fecha = DateTime.Now;
                pedido.Confirmado = null;
                pedido.Preparado = null;
                pedido.Enviado = null;
                pedido.Cobrado = null;
                pedido.Devuelto = null;
                pedido.Anulado = null;
                string emailCliente = User.Identity.Name;
                var cliente = await _context.Clientes.FirstOrDefaultAsync(c => c.Email == emailCliente);
                pedido.ClienteId = cliente.Id;

                

                pedido.EstadoId = 1; // Estado: "Pendiente" (Sin confirmar)
                if (ModelState.IsValid)
                {
                    _context.Add(pedido);
                    await _context.SaveChangesAsync();
                }
                // Se asigna el número de pedido a la variable de sesión
                // que almacena el número de pedido del carrito
                HttpContext.Session.SetString("NumPedido", pedido.Id.ToString());
            }

            //Pruebas para añadir líneas de código
            //Lo tienes en el amigo 



            //Pruebas 
            

                // Crear objeto detalle para agregar el producto al detalle del pedido del carrito
                Detalle detalle = new Detalle();
            string strNumeroPedido = HttpContext.Session.GetString("NumPedido");
            detalle.PedidoId = Convert.ToInt32(strNumeroPedido);
            detalle.ProductoId = id; // El valor id tiene el id del producto a agregar
            detalle.Cantidad = 1;
            detalle.Precio = producto.Precio;
            detalle.Descuento = 0;
            if (ModelState.IsValid)
            {
                _context.Add(detalle);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction("Carrito", "Carrito");
        }

    }


}







