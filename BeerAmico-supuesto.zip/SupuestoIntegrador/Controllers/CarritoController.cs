﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SupuestoIntegrador.Data;
using SupuestoIntegrador.Models;

namespace SupuestoIntegrador.Controllers
{
    public class CarritoController : Controller
    {
        private readonly MvcSupuestoIntegrador _context;

        public CarritoController(MvcSupuestoIntegrador context)
        {
            _context = context;
        }

        // GET: Carrito
        public async Task<IActionResult> Index()
        {
            var mvcSupuestoIntegrador = _context.Detalles.Include(d => d.Pedido).Include(d => d.Producto);
            return View(await mvcSupuestoIntegrador.ToListAsync());
        }

        #region
        //// GET: Carrito/Details/5
        //public async Task<IActionResult> Details(int? id)
        //{
        //    if (id == null || _context.Detalles == null)
        //    {
        //        return NotFound();
        //    }

        //    var detalle = await _context.Detalles
        //        .Include(d => d.Pedido)
        //        .Include(d => d.Producto)
        //        .FirstOrDefaultAsync(m => m.Id == id);
        //    if (detalle == null)
        //    {
        //        return NotFound();
        //    }

        //    return View(detalle);
        //}

        //// GET: Carrito/Create
        //public IActionResult Create()
        //{
        //    ViewData["PedidoId"] = new SelectList(_context.Pedidos, "Id", "Id");
        //    ViewData["ProductoId"] = new SelectList(_context.Productos, "Id", "Descripcion");
        //    return View();
        //}

        //// POST: Carrito/Create
        //// To protect from overposting attacks, enable the specific properties you want to bind to.
        //// For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public async Task<IActionResult> Create([Bind("Id,PedidoId,ProductoId,Cantidad,Precio,Descuento")] Detalle detalle)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        _context.Add(detalle);
        //        await _context.SaveChangesAsync();
        //        return RedirectToAction(nameof(Index));
        //    }
        //    ViewData["PedidoId"] = new SelectList(_context.Pedidos, "Id", "Id", detalle.PedidoId);
        //    ViewData["ProductoId"] = new SelectList(_context.Productos, "Id", "Descripcion", detalle.ProductoId);
        //    return View(detalle);
        //}

        // GET: Carrito/Edit/5
        //public async Task<IActionResult> Edit(int? id)
        //{
        //    if (id == null || _context.Detalles == null)
        //    {
        //        return NotFound();
        //    }

        //    var detalle = await _context.Detalles.FindAsync(id);
        //    if (detalle == null)
        //    {
        //        return NotFound();
        //    }
        //    ViewData["PedidoId"] = new SelectList(_context.Pedidos, "Id", "Id", detalle.PedidoId);
        //    ViewData["ProductoId"] = new SelectList(_context.Productos, "Id", "Descripcion", detalle.ProductoId);
        //    return View(detalle);
        //}

        // POST: Carrito/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public async Task<IActionResult> Edit(int id, [Bind("Id,PedidoId,ProductoId,Cantidad,Precio,Descuento")] Detalle detalle)
        //{
        //    if (id != detalle.Id)
        //    {
        //        return NotFound();
        //    }

        //    if (ModelState.IsValid)
        //    {
        //        try
        //        {
        //            _context.Update(detalle);
        //            await _context.SaveChangesAsync();
        //        }
        //        catch (DbUpdateConcurrencyException)
        //        {
        //            if (!DetalleExists(detalle.Id))
        //            {
        //                return NotFound();
        //            }
        //            else
        //            {
        //                throw;
        //            }
        //        }
        //        return RedirectToAction(nameof(Index));
        //    }
        //    ViewData["PedidoId"] = new SelectList(_context.Pedidos, "Id", "Id", detalle.PedidoId);
        //    ViewData["ProductoId"] = new SelectList(_context.Productos, "Id", "Descripcion", detalle.ProductoId);
        //    return View(detalle);
        //}
        #endregion

        // GET: Carrito/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Detalles == null)
            {
                return NotFound();
            }

            var detalle = await _context.Detalles
                .Include(d => d.Pedido)
                .Include(d => d.Producto)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (detalle == null)
            {
                return NotFound();
            }

            return View(detalle);
        }

        // POST: Carrito/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Detalles == null)
            {
                return Problem("Entity set 'MvcSupuestoIntegrador.Detalles'  is null.");
            }
            var detalle = await _context.Detalles.FindAsync(id);
            if (detalle != null)
            {
                _context.Detalles.Remove(detalle);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool DetalleExists(int id)
        {
          return (_context.Detalles?.Any(e => e.Id == id)).GetValueOrDefault();
        }

        ////Vista de carrito 
        /////GET: PEDIDOS/CARRITO
        //GET: PEDIDOS/CARRITO

        //public async Task<IActionResult> Carrito()
        //{
        //    if (User.IsInRole("Administrador")) return RedirectToAction(nameof(Index));

        //    Cliente? cliente = await _context.Clientes.FirstOrDefaultAsync(c => c.Email == User.Identity.Name);

        //    if (User.IsInRole("Cliente") && cliente == null)
        //    {
        //        return RedirectToAction("Create", "MisDatos", new { role = "Cliente" });
        //    }

        //    var listaPedidos = await _context.Pedidos
        //            .Where(p => p.EstadoId == 1)
        //            .Where(p => p.ClienteId == cliente.Id)
        //            .ToListAsync();

        //    if (listaPedidos.Count > 0)
        //    {
        //        var ultimo = listaPedidos
        //            .OrderByDescending(p => p.Id)
        //            .First(); // Obtener el último pedido pendiente

        //        if (ultimo != null)
        //            HttpContext.Session.SetString("NumPedido", ultimo.Id.ToString());
        //    }

        //    var numPed = HttpContext.Session.GetString("NumPedido");
        //    if (numPed != null && numPed != "0")
        //    {
        //        return RedirectToAction("Carrito", "Carrito", new { id = numPed, c = true });
        //    }

        //    return View();
        //}

        [Authorize(Roles = "Usuario")]
        // GET: Carrito
        public async Task<IActionResult> Carrito()
        {

            if (HttpContext.Session.GetString("NumPedido") == null)
            {
                return RedirectToAction(nameof(CarritoVacio));
            }

            else
            {
                string numPedido = HttpContext.Session.GetString("NumPedido");
                int id = Convert.ToInt32(numPedido);

                var pedidoActual = await _context.Pedidos
                .Include(p => p.Detalles)
                .ThenInclude(x => x.Producto)
                .Include(y  => y.Cliente)
                .FirstOrDefaultAsync(g => g.Id == id);

                return View(pedidoActual);
            }
            #region

            /*string emailUsuario = User.Identity.Name;
            Pedido pedidoActual = null;

            var pendiente = await _context.Estados
                .Where(e => e.Descripcion == "Pendiente")
                .FirstOrDefaultAsync();

            if (pendiente != null)
            {
                var cliente = await _context.Clientes
                    .Where(e => e.Email == emailUsuario)
                    .FirstOrDefaultAsync();

                if (cliente != null)
                {
                    int clienteId = cliente.Id;

                    pedidoActual = await _context.Pedidos
                        .Include(p => p.Detalles)
                        .ThenInclude(x => x.Producto)
                        .Include(p => p.Cliente)
                        .Where(e => e.ClienteId == clienteId && e.EstadoId == pendiente.Id)
                        .FirstOrDefaultAsync();
                }
                else
                {
                    // Manejo si no se encuentra el cliente
                    // Puedes redirigir a una página de error o realizar alguna acción específica.
                    return NotFound("Cliente no encontrado");
                }
            }
            else
            {
                // Manejo si no se encuentra el estado "Pendiente"
                // Puedes redirigir a una página de error o realizar alguna acción específica.
                return NotFound("Estado 'Pendiente' no encontrado");
            }

            return View(pedidoActual);
        }

        public async Task<ActionResult> MenosCantidad(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var detalle = await _context.Detalles.FindAsync(id);
            detalle.Cantidad = detalle.Cantidad - 1;
            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(detalle);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!DetallesExists(detalle.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
            }
            return RedirectToAction(nameof(Carrito));*/
            #endregion
        }

        public ActionResult CarritoVacio()
        {
            return View();
        }

        // GET CarritoMasCantidad




        private bool DetallesExists(int id)
        {
            return _context.Detalles.Any(p => p.Id == id);
        }

        public async Task<IActionResult> MasCantidad(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var detalle = await _context.Detalles.FindAsync(id);
            detalle.Cantidad = detalle.Cantidad + 1;

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(detalle);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!DetallesExists(detalle.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
            }
            return RedirectToAction(nameof(Carrito));
        }

        public async Task<ActionResult> MenosCantidad(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var detalle = await _context.Detalles.FindAsync(id);
            detalle.Cantidad = detalle.Cantidad - 1;
            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(detalle);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!DetallesExists(detalle.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }

            }
            return RedirectToAction(nameof(Carrito));
        }

        // POST Detalles/EliminarLinea

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EliminarLinea(int id)
        {
            /*var detalle = await _context.Detalles.FindAsync(id);
            _context.Detalles.Remove(detalle);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Carrito));
            
             ESTO ES LO MÍO LO DE ABAJO SON COSAS */


            // Encontrar el detalle con el ID proporcionado
            var detalle = await _context.Detalles.FindAsync(id);

            if (detalle == null)
            {
                // Detalle no encontrado, devolver resultado NotFound
                return NotFound();
            }

            // Eliminar el detalle del contexto
            _context.Detalles.Remove(detalle);

            // Guardar cambios en la base de datos antes de verificar si hay más detalles
            await _context.SaveChangesAsync();

            // Verificar si hay más detalles asociados al pedido
            var detallesRestantes = await _context.Detalles
                .Where(d => d.PedidoId == detalle.PedidoId)
                .ToListAsync();

            if (detallesRestantes.Count == 0)
            {
                // Si no hay más detalles, buscar y eliminar el pedido
                var pedido = await _context.Pedidos.FindAsync(detalle.PedidoId);

                if (pedido != null)
                {
                    _context.Pedidos.Remove(pedido);

                    // Guardar cambios en la base de datos
                    await _context.SaveChangesAsync();
                }
            }

            // Redireccionar al usuario a la acción "Index"
            return RedirectToAction(nameof(Carrito));
        }

        // POST Carrito/ConfirmarPedido

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ConfirmarPedido(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Pedido pedido = await _context.Pedidos
                .Include(p => p.Detalles)
                .ThenInclude(p => p.Producto)
                .Where(x => x.Id == id)
                .FirstOrDefaultAsync();

            //se cambia el estado del pedido a confirmado

            var confirmado = await _context.Estados
            .Where(e => e.Descripcion == "Confirmado")
            .FirstOrDefaultAsync();
            pedido.EstadoId = confirmado.Id;
            pedido.Confirmado = DateTime.Now;
            // recorrer las lineas del pedido y para cada línea del pedido,
            // obtener de la BD el producto al que está haciendo referencia y restarle la cantidad de unidades

            foreach (Detalle detalle in pedido.Detalles)
            {
                var producto = await _context.Productos
                    .Where(e => e.Id == detalle.ProductoId)
                    .FirstOrDefaultAsync();
                producto.Stock = producto.Stock - detalle.Cantidad;

                _context.Update(producto);
            }
            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(pedido);
                    await _context.SaveChangesAsync();

                    // Al confirmar el pedido se pone la variable de sesion del pedido actual
                     HttpContext.Session.Remove("NumPedido");
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PedidoExists(pedido.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
            }

            return RedirectToAction(nameof(Index), "Escaparates");
        }

        private bool PedidoExists(int id)
        {
            return _context.Pedidos.Any(p => p.Id == id);
        }
    }
}

